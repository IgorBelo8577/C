﻿using ControleDeVinil.Shared.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleDeVinil.Shared.Dados
{
    internal class DAO<T> where T:class
    {
        private readonly Contexto contexto;

        public DAO(Contexto contexto)
        {
            this.contexto = contexto;
        }

        public IEnumerable<T> ObterDados()
        {
            return this.contexto.Set<T>().ToList();
        }

        public void CriarNovoItem(T novoitem)
        {
            this.contexto.Set<T>().Add(novoitem);
            this.contexto.SaveChanges();
        }

        public void ExcluirItem(T item)
        {
            this.contexto.Set<T>().Remove(item);
            this.contexto.SaveChanges();
        }

        public void AlterarItem(T itemAlterar)
        {
            this.contexto.Set<T>().Update(itemAlterar);
            this.contexto.SaveChanges();
        }

    }
}
