﻿using ControleDeVinil.Shared.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleDeVinil.Shared.Dados
{
    internal class GeneroDAO
    {

        private readonly Contexto contexto;

        public GeneroDAO(Contexto contexto)
        {
            this.contexto = contexto;
        }

        public IEnumerable<Genero> ObterDados()
        {
            return this.contexto.Set<Genero>().ToList();
        }

        public void CriarNovoItem(Genero novoitem)
        {
            this.contexto.Set<Genero>().Add(novoitem);
            this.contexto.SaveChanges();
        }

        public void ExcluirItem(Genero item)
        {
            this.contexto.Set<Genero>().Remove(item);
            this.contexto.SaveChanges();
        }

        public void AlterarItem(Genero itemAlterar)
        {
            this.contexto.Set<Genero>().Update(itemAlterar);
            this.contexto.SaveChanges();

        }
    }
}
