﻿using ControleDeVinil.Shared.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleDeVinil.Shared.Dados
{
    internal class MusicaDAO
    {
        private readonly Contexto contexto;

        public MusicaDAO(Contexto contexto)
        {
            this.contexto = contexto;
        }

        public IEnumerable<Musica> ObterDados()
        {
            return this.contexto.Set<Musica>().ToList();


        }

        public void CriarNovoItem(Musica novoitem)
        {
            this.contexto.Set<Musica>().Add(novoitem);
            this.contexto.SaveChanges();
        }

        public void ExcluirItem(Musica item)
        {
            this.contexto.Set<Musica>().Remove(item);
            this.contexto.SaveChanges();
        }

        public void AlterarItem(Musica itemAlterar)
        {
            this.contexto.Set<Musica>().Update(itemAlterar);
            this.contexto.SaveChanges();

        }
    }
}
