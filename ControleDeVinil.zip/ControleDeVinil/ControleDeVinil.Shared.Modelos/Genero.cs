﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleDeVinil.Shared.Modelos
{
    public class Genero
    {
        public int id { get; set; }

        public string Descricao { get; set; }

    }
}
