﻿namespace ControleDeVinil.Shared.Modelos
{
    public class Artista
    {
        public int Id { get; set; }
        public string Nome { get; set; }

        public string Bio { get; set; }

        public string FotoPerfil { get; set; }

    }
}
