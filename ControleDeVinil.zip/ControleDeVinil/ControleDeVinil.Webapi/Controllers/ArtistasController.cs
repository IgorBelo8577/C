﻿using ControleDeVinil.Shared.Modelos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.NetworkInformation;

namespace ControleDeVinil.Webapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArtistasController : ControllerBase
    {
        private List<Artista> Artistas = new List<Artista>
        {
            new Artista {Id = 1, Nome ="Waldick Soreano", Bio="Rei do Chorinho", FotoPerfil="" },
            new Artista {Id = 2, Nome ="Gustavo Lima", Bio="Embaixador", FotoPerfil="" },
            new Artista {Id = 3, Nome ="Tiao Carrero", Bio="Das Antigas", FotoPerfil="" }
        };

        [HttpGet]

        public IEnumerable<Artista> Get()
        {
            return this.Artistas.ToList();
        }

        [HttpGet("{id}")]

        public IActionResult Get(int id)
        {
            var artista = this.Artistas.FirstOrDefault(a => a.Id == id);
            if (artista != null)
            {
                return Ok(artista);

            }
            return NotFound();
        }


        [HttpPost]
        public async Task<IActionResult> Post(Artista novoArtista)
        {
            novoArtista.Id = this.Artistas.Max(a => a.Id) + 1;
            this.Artistas.Append(novoArtista);
            await Task.Delay(100);
            return Created($"/{novoArtista.Id}", novoArtista);


        }
        [HttpDelete]
        public async Task<IActionResult> Delete(int id, Artista novoArtista)
        {
            try
            {
                await Task.Delay(100);
                if (id = novoArtista.Id)
                {
                    var itemAexcluir = this.Artistas.FirstOrDefault(a => a.Id == id);
                    if (itemAexcluir != null)
                    {
                        if (itemAexcluir.Nome == novoArtista)
                        {

                        }

                    }
                }





            }
        }



    }
}
